var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var parseUrlencoded = bodyParser.urlencoded({ extended: false });
var parseJSON = bodyParser.json();
var connection = require('../connection');//will opening multiple of these cause a problem???
const myrequest = require('request');

router.route('/')
    .post(parseUrlencoded, parseJSON, function (request, response) {//import with branch id, authorization and sub. if can find a second menu, with just branch id, then just add stuff not new menu
        var newV = request.body.newVersion;
        for (var propName in newV) {
            if (newV[propName] === null || newV[propName] === undefined) {
                delete newV[propName];
            }
        }
        var rolesToAdd = [];
        var rolesToRemove = [];
        var currentRevision = request.body;
        var setToAdd = new Set();
        var setToRemove = new Set();
        var setFromNew = new Set();
        var setFromOld = new Set();
        if (currentRevision.newVersion.roles == null) {
            currentRevision.newVersion.roles = [];
        }
        if (currentRevision.oldVersion.roles == null) {
            currentRevision.oldVersion.roles = [];
        }
        for (let role of currentRevision.newVersion.roles) {
            setFromNew.add(role.role);
        }
        for (let role of currentRevision.oldVersion.roles) {
            setFromOld.add(role.role);
        }
        for (let role of currentRevision.newVersion.roles) {
            if (!setFromOld.has(role.role)) {
                setToAdd.add(role);
            }
        }

        for (let role of currentRevision.oldVersion.roles) {
            if (!setFromNew.has(role.role)) {
                setToRemove.add(role);
            }
        }
        var temp = Array.from(setToAdd);
        for (let role of temp) {
            rolesToAdd.push(role);
        }
        temp = Array.from(setToRemove);
        for (let role of temp) {
            rolesToRemove.push(role);
        }

        if (rolesToAdd.length != 0)
            newV.rolesToAdd = rolesToAdd;
        if (rolesToRemove.length != 0)
            newV.rolesToRemove = rolesToRemove;

        if (newV.roles != null) {
            delete newV['roles'];
        }
        var check = true;

        if (newV.specialties.length == request.body.oldVersion.specialties.length) {
            newV.specialties.sort();
            request.body.oldVersion.specialties.sort();
            for (let i = 0; i < newV.specialties.length; i++) {
                if (newV.specialties[i] != request.body.oldVersion.specialties[i]) {
                    check = false;
                    break;
                }
            }
        }
        else { check = false }
        if (check) {
            delete newV['specialties'];
        }
        console.log(newV);
        if (Object.keys(newV).length == 1) {
            response.send({ Message: "empty revision" });
        }
        connection.acquire(function (err, con) {

            con.query('INSERT INTO Revision(dateCreated, newVersion, oldVersion, reviewed) VALUES (?,?,?,?)',
                [request.body.dateCreated, JSON.stringify(newV), request.body.oldVersion.PersonID, false],
                function (err, headerrows, fields) {

                    if (err != null && !response.headersSent) { response.send({ error: err }); con.release(); return; };
                    response.send({ Message: "done" });
                    con.release();
                })
        });
    })

    .get(parseUrlencoded, parseJSON, function (request, response) {
        connection.acquire(function (err, con) {
            con.query('SELECT * FROM Revision WHERE reviewed = ?', [false], function (err, rows, fields) {
                if (err != null && !response.headersSent) { response.send({ error: err }); con.release(); return; };
                var ids = [];
                var versMap = new Map();
                for (let i = 0; i < rows.length; i++) {
                    rows[i].newVersion = JSON.parse(rows[i].newVersion);
                    ids.push(rows[i].oldVersion);
                }
                if(rows.length==0)
                {
                    response.send([]);
                    con.release();
                    return;
                }
                con.query('SELECT * FROM Person WHERE PersonID in (?)', [ids], function (err, persrows, fields) {
                    for (let i = 0; i < persrows.length; i++) {
                        versMap.set(persrows[i].PersonID, i);
                        persrows[i].specialties = JSON.parse(persrows[i].specialties);
                    }
                    for (let i = 0; i < rows.length; i++) {
                        rows[i].oldVersion = persrows[versMap.get(rows[i].oldVersion)];
                    }
                    response.send(rows);
                    con.release();
                });

            })

        });
    })
    .put(parseUrlencoded, parseJSON, function (request, response) {
        connection.acquire(function (err, con) {
            con.query('SELECT * FROM Revision WHERE reviewed = ?', [false], function (err, rows, fields) {
                if (err != null && !response.headersSent) { response.send({ error: err }); con.release(); return; };
                response.send(rows);
                con.release();
            })

        });
    });
router.route('/:ID')
    .get(parseUrlencoded, parseJSON, function (request, response) {
        connection.acquire(function (err, con) {

            con.query('SELECT * FROM Categories WHERE MenuID = ?', [request.params["MenuID"]], function (err, catrows, fields) {

            });
        });
    })
    .post(parseUrlencoded, parseJSON, function (request, response) {
        var fields = request.body.fields;
        var toRemove = request.body.rolesToRemove;
        var toAdd = request.body.rolesToAdd;


        var query = 'UPDATE Person SET ';
        var first = true;
        for (let i = 0; i < fields.length; i++) {
            if (fields[i].status != 2)
                continue;
            if (fields[i].key == "specialties")
                fields[i].value = JSON.stringify(fields[i].value);
            if (fields[i].key != "rolesToAdd" && fields[i].key != "rolesToRemove") {
                if (!first) {
                    query += ', ';
                }
                if (fields[i].value === true || fields[i].value === false) {
                    query += fields[i].key + '=' + fields[i].value;
                }
                else {
                    query += fields[i].key + "='" + fields[i].value + "'";
                }
                first = false;
            }
        }
        query += ' WHERE PersonID = ' + request.params["ID"];
        if (!first) {
            connection.acquire(function (err1, con) {
                if (err1 != null && !response.headersSent) { response.send({ error: err1 }); con.release(); return; };
                con.query(query, [], function (err, rows, fields) {
                    if (err != null && !response.headersSent) { response.send({ error: err }); con.release(); return; };
                    con.release();
                });
            });
        }
        console.log(query);
        var values = [];
        for (let i = 0; i < toAdd.length; i++) {
            if (toAdd[i].status == 2)
                values.push([toAdd[i].value.role, toAdd[i].value.ICUID, toAdd[i].value.PersonID]);
        }
        if (values.length > 0) {
            connection.acquire(function (err1, con) {
                if (err1 != null && !response.headersSent) { response.send({ error: err1 }); con.release(); return; };
                con.query("INSERT INTO Role (role, ICUID, PersonID) VALUES ?", [values], function (err, rows, fields) {
                    if (err != null && !response.headersSent) { response.send({ error: err }); con.release(); return; };
                    con.release();
                });
            });
        }
        var removeIDs = [];
        for (let i = 0; i < toRemove.length; i++) {
            if (toRemove[i].status == 2) {
                removeIDs.push(toRemove[i].value.RoleID);
            }
        }
        if (removeIDs.length > 0) {
            connection.acquire(function (err1, con) {
                if (err1 != null && !response.headersSent) { response.send({ error: err1 }); con.release(); return; };
                con.query("DELETE FROM Role WHERE RoleID in (?)", [removeIDs], function (err, rows, fields) {
                    if (err != null && !response.headersSent) { response.send({ error: err }); con.release(); return; };
                    con.release();
                });
            });
        }
        
        connection.acquire(function (err1, con) {
            if (err1 != null && !response.headersSent) { response.send({ error: err1 }); con.release(); return; };
            con.query("UPDATE Revision SET reviewed = true WHERE RevisionID=?", [request.body.revision], function (err, rows, fields) {
                if (err != null && !response.headersSent) { response.send({ error: err }); con.release(); return; };
                con.release();
                response.send({ Message: "done" });
            });
        });
        //console.log(request.params["ID"]);
        
    });

module.exports = router;